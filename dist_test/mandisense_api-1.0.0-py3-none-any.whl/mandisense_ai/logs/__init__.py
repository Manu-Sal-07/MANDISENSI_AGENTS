# Initializer for logs
