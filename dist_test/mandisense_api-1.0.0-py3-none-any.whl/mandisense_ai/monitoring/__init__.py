# Initializer for monitoring
