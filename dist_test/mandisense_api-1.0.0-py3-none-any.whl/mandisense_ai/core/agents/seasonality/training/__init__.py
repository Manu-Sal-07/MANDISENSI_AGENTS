# Seasonality training helpers
