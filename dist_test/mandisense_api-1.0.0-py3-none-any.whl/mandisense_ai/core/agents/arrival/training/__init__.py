# Initializer for training
