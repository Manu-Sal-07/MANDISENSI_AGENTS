# Initializer for adaptive
