# Initializer for scoring
