# Initializer for causal
