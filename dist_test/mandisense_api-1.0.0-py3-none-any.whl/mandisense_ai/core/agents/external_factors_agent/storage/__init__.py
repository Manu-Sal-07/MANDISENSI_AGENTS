# Initializer for storage
