# Initializer for config
