# Initializer for ingestion
