# Initializer for processing
