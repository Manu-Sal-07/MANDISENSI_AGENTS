# Initializer for tests
