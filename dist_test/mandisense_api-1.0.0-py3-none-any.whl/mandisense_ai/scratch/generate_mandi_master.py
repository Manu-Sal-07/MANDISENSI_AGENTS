import math
import pandas as pd

def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Earth radius in km
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

bengaluru_coords = (12.9716, 77.5946)

# Candidate list with coordinates
candidates = [
    {"mandi_name": "Bangalore", "district": "Bengaluru", "state": "Karnataka", "lat": 13.0225, "lon": 77.5475},
    {"mandi_name": "Kolar", "district": "Kolar", "state": "Karnataka", "lat": 13.1377, "lon": 78.1299},
    {"mandi_name": "Ramanagara", "district": "Ramanagara", "state": "Karnataka", "lat": 12.7233, "lon": 77.2759},
    {"mandi_name": "Chintamani", "district": "Chikkaballapura", "state": "Karnataka", "lat": 13.4005, "lon": 78.0645},
    {"mandi_name": "Chickballapur", "district": "Chikkaballapura", "state": "Karnataka", "lat": 13.4355, "lon": 77.7315},
    {"mandi_name": "Doddaballapur", "district": "Bengaluru Rural", "state": "Karnataka", "lat": 13.2941, "lon": 77.5367},
    {"mandi_name": "Hoskote", "district": "Bengaluru Rural", "state": "Karnataka", "lat": 13.0707, "lon": 77.7981},
    {"mandi_name": "Malur", "district": "Kolar", "state": "Karnataka", "lat": 13.0016, "lon": 77.9392},
    {"mandi_name": "Sidlaghatta", "district": "Chikkaballapura", "state": "Karnataka", "lat": 13.3881, "lon": 77.8631},
    {"mandi_name": "Gowribidanur", "district": "Chikkaballapura", "state": "Karnataka", "lat": 13.6119, "lon": 77.5147},
    {"mandi_name": "Mulbagal", "district": "Kolar", "state": "Karnataka", "lat": 13.1611, "lon": 78.3961},
    {"mandi_name": "Bangarpet", "district": "Kolar", "state": "Karnataka", "lat": 12.9796, "lon": 78.1884},
    {"mandi_name": "Srinivaspur", "district": "Kolar", "state": "Karnataka", "lat": 13.3377, "lon": 78.2131},
    {"mandi_name": "Tumakuru", "district": "Tumakuru", "state": "Karnataka", "lat": 13.3392, "lon": 77.1140},
    {"mandi_name": "Maddur", "district": "Mandya", "state": "Karnataka", "lat": 12.5833, "lon": 77.0500},
    {"mandi_name": "Mandya", "district": "Mandya", "state": "Karnataka", "lat": 12.5218, "lon": 76.8951},
    {"mandi_name": "Channapatna", "district": "Ramanagara", "state": "Karnataka", "lat": 12.6517, "lon": 77.2023},
    {"mandi_name": "Kanakapura", "district": "Ramanagara", "state": "Karnataka", "lat": 12.5539, "lon": 77.4194},
    {"mandi_name": "Magadi", "district": "Ramanagara", "state": "Karnataka", "lat": 12.9575, "lon": 77.2241},
    {"mandi_name": "Nelamangala", "district": "Bengaluru Rural", "state": "Karnataka", "lat": 13.1017, "lon": 77.3872},
    {"mandi_name": "Anekal", "district": "Bengaluru Urban", "state": "Karnataka", "lat": 12.7111, "lon": 77.6961},
    {"mandi_name": "Kunigal", "district": "Tumakuru", "state": "Karnataka", "lat": 13.0242, "lon": 77.0347},
    {"mandi_name": "Gubbi", "district": "Tumakuru", "state": "Karnataka", "lat": 13.3100, "lon": 76.9400},
    {"mandi_name": "Turuvekere", "district": "Tumakuru", "state": "Karnataka", "lat": 13.1600, "lon": 76.7300},
    {"mandi_name": "Tiptur", "district": "Tumakuru", "state": "Karnataka", "lat": 13.2638, "lon": 76.4772},
]

for m in candidates:
    m["distance_from_bengaluru_km"] = haversine(bengaluru_coords[0], bengaluru_coords[1], m["lat"], m["lon"])

# Sort by distance
sorted_mandis = sorted(candidates, key=lambda x: x["distance_from_bengaluru_km"])

# Take top 15
final_15 = sorted_mandis[:15]

# Standardize identifiers
for m in final_15:
    m["mandi_id"] = m["mandi_name"].strip().lower().replace(" ", "_")

# Convert to DataFrame
df = pd.DataFrame(final_15)

# Rearrange columns
cols = ["mandi_id", "mandi_name", "district", "state", "lat", "lon", "distance_from_bengaluru_km"]
df = df[cols]
df = df.rename(columns={"lat": "latitude", "lon": "longitude"})

# Save to CSV
df.to_csv("mandi_master_temp.csv", index=False)

print("Generated mandi_master_temp.csv with top 15 mandis.")
for index, row in df.iterrows():
    print(f"{row['mandi_name']} - {row['distance_from_bengaluru_km']:.2f} km")
