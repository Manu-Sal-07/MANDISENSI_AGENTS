import requests
import json
import time

def test_endpoint():
    url = "http://localhost:8000/v1/predict"
    payload = {"commodity": "tomato", "mandi": "kolar"}
    headers = {"Content-Type": "application/json"}
    
    print("Sending Request 1 (Cache Miss)...")
    start = time.time()
    r1 = requests.post(url, json=payload, headers=headers)
    print(f"Status 1: {r1.status_code}")
    print(f"Body 1: {r1.text[:200]}")
    d1 = r1.json()
    print(f"Latency: {time.time() - start:.2f}s | Cache Hit: {d1.get('cache', {}).get('hit')}")
    
    print("\nSending Request 2 (Cache Hit)...")
    start = time.time()
    r2 = requests.post(url, json=payload, headers=headers)
    print(f"Status 2: {r2.status_code}")
    print(f"Body 2: {r2.text[:200]}")
    d2 = r2.json()
    print(f"Latency: {time.time() - start:.2f}s | Cache Hit: {d2.get('cache', {}).get('hit')}")


if __name__ == "__main__":
    test_endpoint()
