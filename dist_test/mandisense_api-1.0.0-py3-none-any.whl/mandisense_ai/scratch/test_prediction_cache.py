import sys
import os
import time
import json
from pathlib import Path

# Add project root to path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.append(str(BASE_DIR))

from mandisense_ai.services.prediction_cache import get_prediction_cache_key, get_cached_prediction, set_cached_prediction

def test_cache():
    print("Running Redis Caching Validation Tests...")
    
    commodity = "tomato"
    mandi = "kolar"
    req_id = "test-req-123"
    key = get_prediction_cache_key(commodity, mandi)
    
    # 1. Cache Miss (initial)
    res_miss = get_cached_prediction(key, req_id)
    print(f"Initial check (should be None): {res_miss}")
    
    # 2. Set Cache
    sample_data = {
        "prediction": 3.5,
        "confidence": 0.8,
        "status": "success",
        "decision": "HOLD",
        "metadata": {"test": True}
    }
    set_cached_prediction(key, sample_data, req_id)
    print(f"Cache SET for {key}")
    
    # 3. Cache Hit
    res_hit = get_cached_prediction(key, "new-req-456")
    print(f"Cache GET check: Hit={res_hit['cache']['hit']} | New Req ID={res_hit['request_id']}")
    
    assert res_hit['cache']['hit'] == True
    assert res_hit['request_id'] == "new-req-456"
    assert res_hit['prediction'] == 3.5
    
    # 4. Fallback Safety (should not cache)
    fb_data = {"status": "fallback", "prediction": 0.0}
    fb_key = "fallback:test:key"
    set_cached_prediction(fb_key, fb_data, req_id)
    res_fb = get_cached_prediction(fb_key, req_id)
    print(f"Fallback check (should be None): {res_fb}")
    assert res_fb is None

    print("\n✅ Redis Cache Logic Validated!")

if __name__ == "__main__":
    test_cache()
