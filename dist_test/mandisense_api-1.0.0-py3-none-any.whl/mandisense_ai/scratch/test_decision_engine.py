import sys
import os
from pathlib import Path

# Add project root to path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.append(str(BASE_DIR))

from mandisense_ai.core.decision_engine import generate_decision

def test_engine():
    print("Running Refined Decision Engine Validation Tests...")
    
    # 1. Strong Bullish -> HOLD + STRONG
    res1 = generate_decision(3.5, 0.8, {"volatility": 0.2, "supply_stress": 0.7})
    print(f"Test 1 (+3.5, 0.8): {res1['decision']} ({res1['action_strength']}) | Signal Trend: {res1['signals']['trend']}")
    assert res1['decision'] == "HOLD"
    assert res1['action_strength'] == "STRONG"
    assert "short-term outlook" in res1['summary']
    
    # 2. Weak Signal -> Lean HOLD + WEAK (Instead of WAIT)
    res2 = generate_decision(1.0, 0.45, {"volatility": 0.3, "supply_stress": 0.5})
    print(f"Test 2 (+1.0, 0.45): {res2['decision']} ({res2['action_strength']})")
    assert res2['decision'] == "HOLD"
    assert res2['action_strength'] == "WEAK"
    
    # 3. Severe Conflict -> WAIT
    res3 = generate_decision(2.0, 0.6, {"volatility": 0.8, "supply_stress": 0.2}) # Trend UP, Supply HIGH (Stress LOW)
    print(f"Test 3 (Severe Conflict): {res3['decision']} | Signal Conflict: {res3['signals']['conflict']}")
    assert res3['decision'] == "WAIT"
    assert res3['signals']['conflict'] == True
    
    # 4. Fallback
    res4 = generate_decision(0.0, 0.1, {}, status="fallback")
    print(f"Test 4 (Fallback): {res4['decision']} | Action: {res4['action_strength']}")
    assert res4['decision'] == "WAIT"
    assert res4['action_strength'] == "WEAK"

    print("\nAll Refined Test Cases Passed!")


if __name__ == "__main__":
    test_engine()
