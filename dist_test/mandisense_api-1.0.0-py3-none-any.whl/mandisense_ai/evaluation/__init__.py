# Initializer for evaluation
